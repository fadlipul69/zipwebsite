<?php exit;?>{
    "1": {
        "name": "read",
        "style": "blue-light",
        "display": 1,
        "actions": {
            "read:list": 1,
            "read:info": 1,
            "read:copy": 1,
            "read:preview": 1,
            "read:download": 1
        }
    },
    "2": {
        "name": "write",
        "style": "blue-deep",
        "display": 1,
        "actions": {
            "read:list": 1,
            "read:info": 1,
            "read:copy": 1,
            "read:preview": 1,
            "read:download": 1,
            "write:add": 1,
            "write:edit": 1,
            "write:change": 1,
            "write:upload": 1,
            "write:remove": 1
        }
    }
}